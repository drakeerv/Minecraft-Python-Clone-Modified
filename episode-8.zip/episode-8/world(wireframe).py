import math
import random
import time
import noise

import chunk

import block_type
import texture_manager

seed = 0

class World:
	def __init__(self):
		global seed

		self.texture_manager = texture_manager.Texture_manager(16, 16, 256)
		self.blocks = [None]
		
		file = open('blocks.txt', 'r')
		lines = file.readlines()
		file.close()

		for line in lines: 
			exec(line.strip())

		self.texture_manager.generate_mipmaps()
		self.chunks = {}

		seedx = random.randint(-10000, 10000)
		seedy = random.randint(-10000, 10000)
		seedz = random.randint(-10000, 10000)

		seed = f"{seedx}.{seedy}.{seedz}"

		for x in range(8):
			for z in range(8):
				for y in range(8):
					chunk_position = (x - 4, y - 4, z - 4)
					current_chunk = chunk.Chunk(self, chunk_position)

					for i in range(chunk.CHUNK_WIDTH):
						for k in range(chunk.CHUNK_LENGTH):
							for j in range(chunk.CHUNK_HEIGHT):
								#print(self.get_height((float(i + x * chunk.CHUNK_WIDTH) + seedx , float(k + z * chunk.CHUNK_LENGTH) + seedz), 100))
								if self.get_height((float(i + x * chunk.CHUNK_WIDTH) + seedx , float(k + z * chunk.CHUNK_LENGTH) + seedz), 16) == j:
									current_chunk.blocks[i * chunk.CHUNK_LENGTH * chunk.CHUNK_HEIGHT + j * chunk.CHUNK_LENGTH + k] = 1
								else:
									current_chunk.blocks[i * chunk.CHUNK_LENGTH * chunk.CHUNK_HEIGHT + j * chunk.CHUNK_LENGTH + k] = 0

					self.chunks[chunk_position] = current_chunk

		for chunk_position in self.chunks:
			self.chunks[chunk_position].update_mesh()

	def get_height(self, position, multiplier):
		height = noise.pnoise2((position[0]) / 16, (position[1]) / 16) * multiplier

		if height < 1:
			height = -height
			if height < 1:
				height = 1

		return int(round(height, 0))

	def get_block(self, position):
		x, y, z = position

		chunk_x = math.floor(x / chunk.CHUNK_WIDTH)
		chunk_y = math.floor(y / chunk.CHUNK_HEIGHT)
		chunk_z = math.floor(z / chunk.CHUNK_LENGTH)

		local_x = int(x % chunk.CHUNK_WIDTH)
		local_y = int(y % chunk.CHUNK_HEIGHT)
		local_z = int(z % chunk.CHUNK_LENGTH)

		chunk_position = (chunk_x, chunk_y, chunk_z)

		if not chunk_position in self.chunks:
			return self.blocks[0]
		
		return self.blocks[self.chunks[chunk_position].blocks[local_x * chunk.CHUNK_LENGTH * chunk.CHUNK_HEIGHT + local_y * chunk.CHUNK_LENGTH + local_z]]

	def draw(self, position):
		for chunk_position in self.chunks:
			x = int(position[0] / chunk.CHUNK_WIDTH  - chunk_position[0])
			y = int(position[1] / chunk.CHUNK_HEIGHT - chunk_position[1])
			z = int(-position[2] / chunk.CHUNK_LENGTH - chunk_position[2])

			if math.sqrt(x * x + y * y + z * z) < 4:
				self.chunks[chunk_position].draw()

def get_seed():
	global seed

	return seed
