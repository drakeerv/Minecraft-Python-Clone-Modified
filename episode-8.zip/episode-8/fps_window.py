import tkinter as tk

root, canvas, fpsVar, fpsLabel = (None, None, None, None)

def create_window():
    global root, canvas, fpsVar, fpsLabel

    root = tk.Tk()

    canvas = tk.Canvas(root, width = 100, height = 100, bg = 'gray95', relief = 'raised')
    canvas.pack()

    fpsVar = tk.StringVar(value="Loading")

    fpsLabel = tk.Label(root, textvariable=fpsVar)
    icon = tk.PhotoImage(file ="textures/icon.png")

    fpsLabel.place(relx=0.5, rely=0.6, anchor=tk.CENTER)

    canvas.create_window(100, 100)

    root.resizable(0, 0)
    root.title("Minecraft Python Info")
    root.iconphoto(False, icon) 
    root.geometry("100x100")

def update_fps(fps):
    global root, canvas, fpsVar, fpsLabel

    fpsVar.set(f"FPS: {fps}")

    root.update_idletasks()